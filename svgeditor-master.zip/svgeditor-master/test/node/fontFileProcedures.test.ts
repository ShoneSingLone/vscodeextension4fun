import * as assert from 'assert';
import {collectSystemFonts, collectSystemFontFilePaths} from "../../src/node/fontFileProcedures";

describe("fontHelpers", () => {
    it("collectSystemFonts", async () => {
        // console.log(await collectSystemFonts());
    });
});
